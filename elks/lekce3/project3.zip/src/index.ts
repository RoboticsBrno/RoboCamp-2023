import { SmartLed, LED_WS2812 } from "smartled";
import * as colors from "./libs/colors.js"

// Tady si napište své řešení