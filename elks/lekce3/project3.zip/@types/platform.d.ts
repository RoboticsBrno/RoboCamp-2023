declare const PlatformInfo: {
    /**
     * The name of the platform the program is running on.
     */
    name: string
}
